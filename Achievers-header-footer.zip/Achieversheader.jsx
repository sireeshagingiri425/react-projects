import React, { Component } from 'react'
import './style.css'
 class Achieversheader extends Component {
  render() {
    return (
      <div className='maincontainer'>
        <div className='logo'>
            <img src="https://www.achieversit.com/assets/images/logo-white.png"/>
        </div>
        <div className='navbar'>
       <ul>
        <li>AllCourses</li>
        <li>Placements</li>
        <li>Internship</li>
        <li>Existingstudent</li>
        <li>AboutUs</li>
        <li>Reviews</li>
        <li>Blog</li>
        </ul>
        </div>
        
      </div>
     
    )
  }
  
}

export default Achieversheader;
