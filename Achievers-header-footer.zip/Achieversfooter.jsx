import React, { Component } from 'react'
import './Footer.css'
class Achieversfooter extends Component {
    render() {
        return (

            <div>
                <img src='https://tse1.mm.bing.net/th?id=OIP.ntCJT9NrTupx01VmWaqmfgHaDe&pid=Api&P=0&h=220' style={{width:'100%',height:'300px'}}/>
            <div className='container'>
                <div className='firstrow'>
                    <img src="https://www.achieversit.com/assets/images/logo-white.png" />
                    <p>
                        AchieversIT - Provides a wide group of opportunities for freshers and
                        Experienced candidate who can develop their skills
                        and build their career opportunities across multiple Companies.
                    </p>
                </div>
                <div className='secondrow'>
                    <h2>COMPANY</h2>
                    <ul>
                        <li>Home</li>
                        <li>Placements</li>
                        <li>Corporate Training</li>
                        <li>Contact US</li>
                        </ul>
                </div>

                <div className='thirdrow'>
                <h2>TRENDING COURSES</h2>
                    <ul>
                        <li>UI Development Course</li>
                        <li>Angular JS Course</li>
                        <li>React JS Course</li>
                        <li>Digital Marketing Course</li>
                        <li>Python Course</li>

                        </ul>
                </div>

                <div className='fourthrow'>
                <h2>CONTACT INFO</h2>
                    <ul>
                        <li>#63, 1st Floor, 16th Main, 8th Cross,BTM 1st Stage, Bangalore, India - 560029</li>
                        <li>India : +91 8431-040-457</li>
                        <li>info@achieversit.com</li>
                    
                        </ul>
                </div>

            </div>
            </div>
        )
    }
}
export default Achieversfooter;
